﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Desktop_01_3961
{
    public partial class MainWindowVM: ObservableObject
    {
        [ObservableProperty]
        public ObservableCollection<Student> students;

     
        [ObservableProperty]
        public Student selected_Student= null;

        public MainWindowVM()
        {
            students = new ObservableCollection<Student>();

            BitmapImage image1 = new BitmapImage(new Uri("/Images/1.png", UriKind.Relative));
            students.Add(new Student(24, "Johmcc", "Cardy", image1, "EG/2020/3961",2.37,"2000.09.12"));
            BitmapImage image2 = new BitmapImage(new Uri("/Images/2.png", UriKind.Relative));
            students.Add(new Student(30, "Johdss", "Cardwe", image2, "EG/2020/3961", 2.37, "2000.09.12"));
            BitmapImage image3 = new BitmapImage(new Uri("/Images/3.png", UriKind.Relative));
            students.Add(new Student(12, "Johcvk", "Cardwdy", image3, "EG/2020/3961", 2.37, "2000.09.12"));
            BitmapImage image4 = new BitmapImage(new Uri("/Images/4.png", UriKind.Relative));
            students.Add(new Student(20, "Johwwz", "Cardgty", image4, "EG/2020/3961", 2.37, "2000.09.12"));
            BitmapImage image5 = new BitmapImage(new Uri("/Images/5.png", UriKind.Relative));
            students.Add(new Student(28, "Johssz", "Cardgty", image5, "EG/2020/3961", 2.37, "2000.09.12"));
            BitmapImage image6 = new BitmapImage(new Uri("/Images/6.png", UriKind.Relative));
            students.Add(new Student(32, "Johfhz", "Cardgty", image6, "EG/2020/3961", 2.37, "2000.09.12"));


        }


        public void CloseMainWindow()
        {
            Application.Current.MainWindow.Close();
        }




        [RelayCommand]
        public void messege()
        {

            MessageBox.Show($"{selected_Student.FirstName} GPA value must be between 0 and 4.", "Error");
        }

        [RelayCommand]
        public void AddStudent()
        {
            var vm = new AddStudentWindowVM();
            vm.title = "ADD STUDENT";
            AddStudentWindow window = new AddStudentWindow(vm);
            window.ShowDialog();

            if (vm.Student.FirstName != null)
            {
                students.Add(vm.Student);
            }
        }






        [RelayCommand]
        public void EditStudent()
        {
            if (selected_Student != null)
            {
                var vm = new AddStudentWindowVM(selected_Student);
                vm.title = "EDIT STUDENT";
                var window = new AddStudentWindow(vm);

                window.ShowDialog();


                int index = students.IndexOf(selected_Student);
                students.RemoveAt(index);
                students.Insert(index, vm.Student);

            }
            else
            {
                MessageBox.Show("Please Select the student", "Warning!");
            }
        }


        [RelayCommand]
        public void Delete()
        {
            if (selected_Student != null)
            {
                string name = selected_Student.FirstName;
                students.Remove(selected_Student);
                MessageBox.Show($"{name} is Deleted successfuly.", "DELETED \a ");

            }
            else
            {
                MessageBox.Show("Plese Select Student before Delete.", "Error");


            }
        }

    }
}
