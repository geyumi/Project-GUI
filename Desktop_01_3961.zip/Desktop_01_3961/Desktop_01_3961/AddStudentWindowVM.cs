﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows;
using System.Windows.Controls;

namespace Desktop_01_3961
{
    public partial class AddStudentWindowVM:ObservableObject
    {
        [ObservableProperty]
        public string firstname;


        [ObservableProperty]
        public string lastname;

        [ObservableProperty]
        public int age;

        [ObservableProperty]
        public string dateofbirth;


        [ObservableProperty]
        public string indexno;

        [ObservableProperty]
        public double gpa;

        [ObservableProperty]
        public string title;

        [ObservableProperty]
       
        public BitmapImage selected_Image;



        public AddStudentWindowVM(Student u)
        {
            Student = u;

            firstname = Student.FirstName;
            lastname = Student.LastName;
            age = Student.Age;
            gpa = Student.GPA;
            dateofbirth = Student.DateOfBirth;
            selected_Image = Student.Image;
            indexno = Student.IndexNo;

        }

        public AddStudentWindowVM()
        {
        }

        [RelayCommand]
        public void UploadPhoto()
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files | *.bmp; *.png; *.jpg";
            dialog.FilterIndex = 1;
            if (dialog.ShowDialog() == true)
            {
                selected_Image = new BitmapImage(new Uri(dialog.FileName));

                MessageBox.Show("Image successfuly uploded!", "successfull");
            }
        }


      

        public Student Student { get; private set; }
        public Action CloseAction { get; internal set; }




        [RelayCommand]
        public void Save()
        { 

            if (gpa < 0 || gpa > 4)
            {
                MessageBox.Show("GPA value must be between 0 and 4.", "Error");
                return;
            }
            if (Student == null)
            {

                Student = new Student()
                {
                    FirstName = firstname,
                    LastName = lastname,
                    Age = age,
                    DateOfBirth = dateofbirth,
                    Image = selected_Image,
                    IndexNo = indexno,
                    GPA = gpa

                };


            }
            else
            {

                Student.FirstName = firstname;
                Student.LastName = lastname;
                Student.Age = age;
                Student.GPA = gpa;
                Student.Image = selected_Image;
                Student.DateOfBirth = dateofbirth;
                Student.IndexNo= indexno;


            }

         
            if (Student.FirstName != null)
            {

                CloseAction();
            }
            Application.Current.MainWindow.Show();


        }

    }
   
}

