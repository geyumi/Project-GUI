﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace Desktop_01_3961
{
    public class Student
    {
        public int Age { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public BitmapImage Image { get; set; }
        public string IndexNo { get; set; }
        public Double GPA { get; set; }
        public string DateOfBirth { get; set; }
        public string ImageURL
        {
            get
            {
                return $"/Images/{Image}";
            }
        }

        public Student(int age, string firstName, string lastName, BitmapImage image, string indexNo, double gPA, string dateOfBirth)
        {
            Age = age;
            FirstName = firstName;
            LastName = lastName;
            Image = image;
            IndexNo = indexNo;
            GPA = gPA;
            DateOfBirth = dateOfBirth;
        }

        public Student()
        {
        }
    }
}
